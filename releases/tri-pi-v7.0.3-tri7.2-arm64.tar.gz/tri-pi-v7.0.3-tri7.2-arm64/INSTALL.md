# TRI-PI Wallet Appliance Installation Guide (tri7d)

## Quick Install

sudo ./install.sh

What gets installed:
- tri7d binary -> /usr/local/bin/tri7d  (also tri7-balances)
- tri7 wallet CLI -> /usr/local/bin/tri7  (create-seed / info / send)
- store_gapfix -> /usr/local/bin/store_gapfix (chain store repair)
- tri7-appliance -> /usr/local/bin/tri7-appliance (status/backup/restore/upgrade)
- Config       -> <data>/triangles.conf (rpcuser/rpcpassword; ports via systemd wrapper)
- Wallet       -> <data>/wallet.dat — a NEW 24-word wallet is created by the
                  installer; the words are shown ONCE, write them on paper
- systemd      -> triangles.service: tri7d --forever --wallet, RPC 19112,
                  P2P 24113 loopback-only, tor SOCKS 9050, onion seeds,
                  nft no-public-clearnet policy active

Status: tri7-appliance status                (balance, staking, peers, wallet)
        tri7d --status --state-dir <data>    (JSON: height, peers, staleness)
Sync:   fresh sync via P2P gap-fill (default) or TRI_PI_BOOTSTRAP_URL archive.
